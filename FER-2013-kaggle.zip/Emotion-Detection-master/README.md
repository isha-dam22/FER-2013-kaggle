# PyPower Project - Emotion Detection using AI

## Emotion Detection

- Kaggle Dataset :- https://www.kaggle.com/c/challenges-in-representation-learning-facial-expression-recognition-challenge/data.

- Use train.py file to train the model.

- Change the number of classes according to you.

- Do Experiment with different pre-trained models.

- Execute the test.py file to run the Emotion Detection.

- Enjoy Deep Learning.

## The detailed tutorial is available in this video. Please do refer for better understanding.

- https://youtu.be/PulKlAZRoAY
